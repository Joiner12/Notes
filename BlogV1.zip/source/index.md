<div class="container;" style="background:url('https://infinitypro-img.infinitynewtab.com/findaphoto/bigLink/17055.jpg');">
<i class="fa fa-battery-three-quarters" aria-hidden="true"></i> Welcome to my paradise.
<br>
<img src="https://gitee.com/RiskyJR/pic-bed/raw/master/aysao-e2vn1.gif">
</div>





<img src="https://infinitypro-img.infinitynewtab.com/findaphoto/bigLink/17055.jpg">

