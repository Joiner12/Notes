clc;
Copy_of_blu_data_analyse_dynamic();
% return;